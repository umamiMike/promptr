-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Sep 04, 2015 at 12:06 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `promptr_app`
--
CREATE DATABASE IF NOT EXISTS `promptr_app` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `promptr_app`;

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE IF NOT EXISTS `answers` (
  `answer` text,
  `question_id` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=342 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`answer`, `question_id`, `id`) VALUES
('', 252, 277),
('', 253, 278),
('', 254, 279),
('', 254, 280),
('asdf\r\n\r\n', 255, 281),
('asdf\r\n\r\n', 255, 282),
('', 256, 283),
('', 256, 284),
('', 256, 285),
('', 257, 286),
('', 258, 287),
('I dont know', 258, 288),
('I still dont know', 258, 289),
('', 259, 290),
('', 260, 291),
('dsv', 261, 292),
('asdf', 262, 293),
('asdf', 263, 294),
('asdf', 262, 295),
('asdf', 262, 296),
('asdf asdfj asdf kljasdjkf askldfj ask''df jk''waf lk asmdf as/kl df amsdf /,jasdfm asdf ,.asdm f as.df asml; df \r\njmawdl/f mzsdfl asdfm asd;lf masdfk asdfm asd f\r\nasdfkn asdlfmasdf asdfm, asd ,f asmdf ', 263, 297),
('', 264, 298),
('', 265, 299),
('', 266, 300),
('', 266, 301),
('', 267, 302),
('', 268, 303),
('', 269, 304),
('', 269, 305),
('', 276, 306),
('', 277, 307),
('', 300, 308),
('', 301, 309),
('', 302, 310),
('', 303, 311),
('', 304, 312),
('', 305, 313),
('', 315, 314),
('', 316, 315),
('', 317, 316),
('da vinci', 318, 317),
('', 323, 318),
('', 324, 319),
('Who''s Monet', 326, 320),
('', 327, 321),
('', 328, 322),
('', 329, 323),
('', 330, 324),
('', 330, 325),
('', 331, 326),
('', 332, 327),
('', 333, 328),
('', 334, 329),
('', 335, 330),
('', 336, 331),
('', 337, 332),
('', 338, 333),
('', 339, 334),
('Promptr', 340, 335),
('That it works at all....and is super pretty.', 341, 336),
('It makes questions for you to ask yourself so you can figure out what you are thinking.\r\n', 342, 337),
('It is getting there.', 343, 338),
('4 days at this point.', 344, 339),
('Lots.  Glad to be learning javascript.', 345, 340),
('Mike Ian Chris Don.', 346, 341);

-- --------------------------------------------------------

--
-- Table structure for table `promptrs`
--

CREATE TABLE IF NOT EXISTS `promptrs` (
  `name` varchar(255) DEFAULT NULL,
  `trending` int(11) DEFAULT NULL,
  `example` int(11) DEFAULT NULL,
  `topic_id` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `promptrs`
--

INSERT INTO `promptrs` (`name`, `trending`, `example`, `topic_id`, `id`) VALUES
('New Novel', 1, 0, 12, 21),
('Newer Novel', 0, 0, 12, 22),
('A novel new novel', 0, 0, 12, 23),
('About your app', 2, 0, 12, 24);

-- --------------------------------------------------------

--
-- Table structure for table `promptrs_questions`
--

CREATE TABLE IF NOT EXISTS `promptrs_questions` (
  `promptr_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `promptrs_questions`
--

INSERT INTO `promptrs_questions` (`promptr_id`, `question_id`, `id`) VALUES
(1, 1, 1),
(1, 2, 2),
(1, 3, 3),
(2, 4, 4),
(2, 5, 5),
(2, 6, 6),
(1, 7, 7),
(1, 8, 8),
(1, 9, 9),
(1, 13, 10),
(1, 14, 11),
(1, 15, 12),
(3, 16, 13),
(3, 17, 14),
(3, 18, 15),
(3, 19, 16),
(3, 20, 17),
(4, 21, 18),
(4, 22, 19),
(4, 23, 20),
(5, 24, 21),
(5, 25, 22),
(4, 26, 23),
(4, 27, 24),
(4, 28, 25),
(6, 29, 26),
(7, 30, 27),
(7, 31, 28),
(7, 32, 29),
(18, 33, 30),
(18, 34, 31),
(18, 35, 32),
(18, 36, 33),
(18, 37, 34),
(18, 38, 35),
(18, 39, 36),
(18, 40, 37),
(21, 41, 38),
(24, 42, 39),
(24, 43, 40),
(24, 44, 41),
(24, 45, 42),
(24, 46, 43),
(24, 47, 44),
(24, 48, 45);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `question` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question`, `description`, `id`) VALUES
('What did you do yesterday?', '', 30),
('What are you going to do today?', '', 31),
('What might keep you from completing your work today?', '', 32),
('Whos Monet', '', 38),
('whl''s', '', 39),
('Who are our characters going to be?', 'I have no idea', 41),
('What is the name of the app', '', 42),
('what is your favorite part?', '', 43),
('What does it do?', '', 44),
('Is it easy to use?', '', 45),
('How long did it take to create?', '', 46),
('what do you still have to work on?', '', 47),
('Who are the contributors?', '', 48);

-- --------------------------------------------------------

--
-- Table structure for table `temp_questions`
--

CREATE TABLE IF NOT EXISTS `temp_questions` (
  `question` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=347 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `temp_questions`
--

INSERT INTO `temp_questions` (`question`, `description`, `id`) VALUES
('What is the name of the app', '', 340),
('what is your favorite part?', '', 341),
('What does it do?', '', 342),
('Is it easy to use?', '', 343),
('How long did it take to create?', '', 344),
('what do you still have to work on?', '', 345),
('Who are the contributors?', '', 346);

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE IF NOT EXISTS `topics` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`name`, `id`) VALUES
('Writing', 11),
('Brainstorming', 12),
('Scrum', 13);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `promptrs`
--
ALTER TABLE `promptrs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `promptrs_questions`
--
ALTER TABLE `promptrs_questions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `temp_questions`
--
ALTER TABLE `temp_questions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=342;
--
-- AUTO_INCREMENT for table `promptrs`
--
ALTER TABLE `promptrs`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `promptrs_questions`
--
ALTER TABLE `promptrs_questions`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `temp_questions`
--
ALTER TABLE `temp_questions`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=347;
--
-- AUTO_INCREMENT for table `topics`
--
ALTER TABLE `topics`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
